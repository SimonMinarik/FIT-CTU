var searchData=
[
  ['openhour',['openhour',['../classapp_1_1corona_1_1models_1_1_hygienic_station.html#a4275be54db76186b784754ad52dd7885',1,'app::corona::models::HygienicStation']]]
];
