var searchData=
[
  ['logout_5fview_2epy',['logout_view.py',['../logout__view_8py.html',1,'']]]
];
