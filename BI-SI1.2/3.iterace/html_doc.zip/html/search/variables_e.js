var searchData=
[
  ['root_5furlconf',['ROOT_URLCONF',['../namespaceapp_1_1app_1_1settings.html#aeea25bc27cd24a96741399e2068f3531',1,'app::app::settings']]]
];
