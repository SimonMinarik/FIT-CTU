var searchData=
[
  ['edit_5fuser',['edit_user',['../classapp_1_1corona_1_1data__layer_1_1interfaces_1_1user__data__access__interface_1_1_user_data_access_interface.html#af423f7e6107f2d4dce16b99329f72b92',1,'app.corona.data_layer.interfaces.user_data_access_interface.UserDataAccessInterface.edit_user()'],['../classapp_1_1corona_1_1data__layer_1_1user__data__access_1_1_user_data_access.html#af423f7e6107f2d4dce16b99329f72b92',1,'app.corona.data_layer.user_data_access.UserDataAccess.edit_user()']]]
];
