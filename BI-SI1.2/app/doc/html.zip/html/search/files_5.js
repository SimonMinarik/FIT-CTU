var searchData=
[
  ['handler_5ffactory_2epy',['handler_factory.py',['../handler__factory_8py.html',1,'']]],
  ['homepage_2emd',['homepage.md',['../homepage_8md.html',1,'']]]
];
