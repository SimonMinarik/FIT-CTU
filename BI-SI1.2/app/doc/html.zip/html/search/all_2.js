var searchData=
[
  ['base_5fdir',['BASE_DIR',['../namespaceapp_1_1app_1_1settings.html#a6c7db55cb69a3846d254023debc5b6b6',1,'app::app::settings']]],
  ['bed',['bed',['../classapp_1_1corona_1_1models_1_1_place.html#a6ca1c73b60696cb8d23d257deb53d251',1,'app::corona::models::Place']]],
  ['birthid',['birthid',['../classapp_1_1corona_1_1forms_1_1_patient_register_form.html#a5dc0c63454d51f1f59757dd789739c04',1,'app.corona.forms.PatientRegisterForm.birthid()'],['../classapp_1_1corona_1_1models_1_1_patient.html#a5dc0c63454d51f1f59757dd789739c04',1,'app.corona.models.Patient.birthid()']]]
];
