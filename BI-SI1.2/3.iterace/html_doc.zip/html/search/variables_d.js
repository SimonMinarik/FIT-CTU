var searchData=
[
  ['password',['password',['../classapp_1_1corona_1_1forms_1_1_login_form.html#a9dbb300e28bc21c8dab41b01883918eb',1,'app.corona.forms.LoginForm.password()'],['../classapp_1_1corona_1_1forms_1_1_patient_register_form.html#a9dbb300e28bc21c8dab41b01883918eb',1,'app.corona.forms.PatientRegisterForm.password()']]],
  ['patient',['patient',['../classapp_1_1corona_1_1models_1_1_quarantine.html#ab239050404f0ab239db912a736e8b96a',1,'app.corona.models.Quarantine.patient()'],['../classapp_1_1corona_1_1models_1_1_covid_pass.html#ab239050404f0ab239db912a736e8b96a',1,'app.corona.models.CovidPass.patient()']]],
  ['phone',['phone',['../classapp_1_1corona_1_1forms_1_1_patient_register_form.html#a2ecf9435d45677655f383bc33b8fb92b',1,'app.corona.forms.PatientRegisterForm.phone()'],['../classapp_1_1corona_1_1models_1_1_patient.html#a2ecf9435d45677655f383bc33b8fb92b',1,'app.corona.models.Patient.phone()']]],
  ['place',['place',['../classapp_1_1corona_1_1models_1_1_quarantine.html#a05f4db0d3aa9dc5c00fbe530bfd8fb7c',1,'app::corona::models::Quarantine']]],
  ['price',['price',['../classapp_1_1corona_1_1models_1_1_covid_test.html#a4dd5ee47dc4a408b73089ec6f8160083',1,'app::corona::models::CovidTest']]]
];
