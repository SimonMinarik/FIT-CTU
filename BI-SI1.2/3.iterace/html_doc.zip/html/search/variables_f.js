var searchData=
[
  ['secret_5fkey',['SECRET_KEY',['../namespaceapp_1_1app_1_1settings.html#a4979e7faaf927fd6eff9849411f9e3c6',1,'app::app::settings']]],
  ['standard',['standard',['../classapp_1_1corona_1_1models_1_1_place.html#a528ee3c70bd5eab258de3ef941fb1d05',1,'app::corona::models::Place']]],
  ['startdate',['startdate',['../classapp_1_1corona_1_1models_1_1_quarantine.html#a2ea80bf6b5542b5a3448cf743f96b5ae',1,'app::corona::models::Quarantine']]],
  ['static_5furl',['STATIC_URL',['../namespaceapp_1_1app_1_1settings.html#a428f2ec992bf4fd72c3c6344615535b0',1,'app::app::settings']]],
  ['surname',['surname',['../classapp_1_1corona_1_1forms_1_1_patient_register_form.html#a7bbddf7f11a9d311a9b6627d6562ab63',1,'app.corona.forms.PatientRegisterForm.surname()'],['../classapp_1_1corona_1_1models_1_1_patient.html#a7bbddf7f11a9d311a9b6627d6562ab63',1,'app.corona.models.Patient.surname()'],['../classapp_1_1corona_1_1models_1_1_administrative.html#a7bbddf7f11a9d311a9b6627d6562ab63',1,'app.corona.models.Administrative.surname()'],['../classapp_1_1corona_1_1models_1_1_doctor.html#a7bbddf7f11a9d311a9b6627d6562ab63',1,'app.corona.models.Doctor.surname()']]]
];
