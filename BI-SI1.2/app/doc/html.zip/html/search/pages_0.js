var searchData=
[
  ['readme',['README',['../md___users_mnrk__documents__skola_5_8__semester__b_i-_s_i1_82_testovani_koronaviru_app__r_e_a_d_m_e.html',1,'']]]
];
