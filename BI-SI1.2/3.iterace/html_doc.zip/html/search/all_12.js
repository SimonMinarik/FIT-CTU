var searchData=
[
  ['templates',['TEMPLATES',['../namespaceapp_1_1app_1_1settings.html#a24cf38fb957c013ca45af12cb44f1337',1,'app::app::settings']]],
  ['test_5fresults',['TEST_RESULTS',['../classapp_1_1corona_1_1models_1_1_covid_pass.html#aae2564b1fc488765ab31ac5a96a9d9c2',1,'app::corona::models::CovidPass']]],
  ['testdate',['testdate',['../classapp_1_1corona_1_1models_1_1_covid_pass.html#ab68653b19a3b7dda9fe19cd6bd974a38',1,'app::corona::models::CovidPass']]],
  ['testresult',['testresult',['../classapp_1_1corona_1_1models_1_1_covid_pass.html#a959f9f1bc69173aa76e173759a88278b',1,'app::corona::models::CovidPass']]],
  ['tests_2epy',['tests.py',['../tests_8py.html',1,'']]],
  ['time_5fzone',['TIME_ZONE',['../namespaceapp_1_1app_1_1settings.html#a037ffded91b7904e73dda92d116594c6',1,'app::app::settings']]],
  ['title',['title',['../classapp_1_1corona_1_1models_1_1_doctor.html#a051e403214cb6872ad3fe4e50302a6ee',1,'app::corona::models::Doctor']]],
  ['type',['type',['../classapp_1_1corona_1_1models_1_1_covid_test.html#a7aead736a07eaf25623ad7bfa1f0ee2d',1,'app::corona::models::CovidTest']]]
];
