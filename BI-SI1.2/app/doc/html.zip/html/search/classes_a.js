var searchData=
[
  ['userdataaccess',['UserDataAccess',['../classapp_1_1corona_1_1data__layer_1_1user__data__access_1_1_user_data_access.html',1,'app::corona::data_layer::user_data_access']]],
  ['userdataaccessinterface',['UserDataAccessInterface',['../classapp_1_1corona_1_1data__layer_1_1interfaces_1_1user__data__access__interface_1_1_user_data_access_interface.html',1,'app::corona::data_layer::interfaces::user_data_access_interface']]],
  ['userhandler',['UserHandler',['../classapp_1_1corona_1_1business__layer_1_1handlers_1_1user__handler_1_1_user_handler.html',1,'app::corona::business_layer::handlers::user_handler']]],
  ['userhandlerinterface',['UserHandlerInterface',['../classapp_1_1corona_1_1business__layer_1_1handlers_1_1interfaces_1_1user__handler__interface_1_1_user_handler_interface.html',1,'app::corona::business_layer::handlers::interfaces::user_handler_interface']]]
];
