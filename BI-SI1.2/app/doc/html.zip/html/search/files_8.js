var searchData=
[
  ['manage_2epy',['manage.py',['../manage_8py.html',1,'']]],
  ['models_2epy',['models.py',['../models_8py.html',1,'']]]
];
