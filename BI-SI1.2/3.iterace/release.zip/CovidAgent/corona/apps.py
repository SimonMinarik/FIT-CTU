from django.apps import AppConfig


class CoronaConfig(AppConfig):
    """!
    Django class for handling the registered apps
    """
    name = 'corona'
