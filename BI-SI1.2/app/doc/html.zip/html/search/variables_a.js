var searchData=
[
  ['manager',['manager',['../classapp_1_1corona_1_1models_1_1_hygienic_station.html#a23416379944e641a8ad6bdbc95ef1859',1,'app::corona::models::HygienicStation']]],
  ['middleware',['MIDDLEWARE',['../namespaceapp_1_1app_1_1settings.html#a1c6780d063beebde4d00e2c1c45c3192',1,'app::app::settings']]]
];
