var searchData=
[
  ['indexview',['IndexView',['../classapp_1_1corona_1_1presentation__layer_1_1views_1_1index__view_1_1_index_view.html',1,'app::corona::presentation_layer::views::index_view']]]
];
