var searchData=
[
  ['name',['name',['../classapp_1_1corona_1_1apps_1_1_corona_config.html#a8ccf841cb59e451791bcb2e1ac4f1edc',1,'app.corona.apps.CoronaConfig.name()'],['../classapp_1_1corona_1_1forms_1_1_patient_register_form.html#ab74e6bf80237ddc4109968cedc58c151',1,'app.corona.forms.PatientRegisterForm.name()'],['../classapp_1_1corona_1_1models_1_1_patient.html#ab74e6bf80237ddc4109968cedc58c151',1,'app.corona.models.Patient.name()'],['../classapp_1_1corona_1_1models_1_1_administrative.html#ab74e6bf80237ddc4109968cedc58c151',1,'app.corona.models.Administrative.name()'],['../classapp_1_1corona_1_1models_1_1_doctor.html#ab74e6bf80237ddc4109968cedc58c151',1,'app.corona.models.Doctor.name()']]]
];
