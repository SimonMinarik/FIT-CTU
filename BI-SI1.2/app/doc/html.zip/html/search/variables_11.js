var searchData=
[
  ['urlpatterns',['urlpatterns',['../namespaceapp_1_1app_1_1urls.html#a885d935e702b2639d5893d720e71fde8',1,'app::app::urls']]],
  ['use_5fi18n',['USE_I18N',['../namespaceapp_1_1app_1_1settings.html#aa385f7186a262f3a197d89b86cd5b44f',1,'app::app::settings']]],
  ['use_5fl10n',['USE_L10N',['../namespaceapp_1_1app_1_1settings.html#a2578e043379f868f8693d8299d915972',1,'app::app::settings']]],
  ['use_5ftz',['USE_TZ',['../namespaceapp_1_1app_1_1settings.html#a1ad6572b69b47cfda1778bf6e9cb6343',1,'app::app::settings']]],
  ['user',['user',['../classapp_1_1corona_1_1models_1_1_patient.html#a5cc32e366c87c4cb49e4309b75f57d64',1,'app.corona.models.Patient.user()'],['../classapp_1_1corona_1_1models_1_1_administrative.html#a5cc32e366c87c4cb49e4309b75f57d64',1,'app.corona.models.Administrative.user()'],['../classapp_1_1corona_1_1models_1_1_doctor.html#a5cc32e366c87c4cb49e4309b75f57d64',1,'app.corona.models.Doctor.user()']]],
  ['username',['username',['../classapp_1_1corona_1_1forms_1_1_login_form.html#a0adcbe0e0e6f64a29b1d205ede9632c1',1,'app.corona.forms.LoginForm.username()'],['../classapp_1_1corona_1_1forms_1_1_patient_register_form.html#a0adcbe0e0e6f64a29b1d205ede9632c1',1,'app.corona.forms.PatientRegisterForm.username()']]]
];
