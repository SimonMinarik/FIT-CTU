var searchData=
[
  ['wsgi_2epy',['wsgi.py',['../wsgi_8py.html',1,'']]]
];
