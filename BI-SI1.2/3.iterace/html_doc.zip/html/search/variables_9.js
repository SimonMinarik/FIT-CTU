var searchData=
[
  ['language_5fcode',['LANGUAGE_CODE',['../namespaceapp_1_1app_1_1settings.html#a85bdb273c38bd7f0a06a3a38aa81225c',1,'app::app::settings']]]
];
