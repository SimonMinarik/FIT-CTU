var searchData=
[
  ['index_5fview_2epy',['index_view.py',['../index__view_8py.html',1,'']]],
  ['indexview',['IndexView',['../classapp_1_1corona_1_1presentation__layer_1_1views_1_1index__view_1_1_index_view.html',1,'app::corona::presentation_layer::views::index_view']]],
  ['installed_5fapps',['INSTALLED_APPS',['../namespaceapp_1_1app_1_1settings.html#a24571ea54b864ef40da4c957ca1cb54e',1,'app::app::settings']]]
];
