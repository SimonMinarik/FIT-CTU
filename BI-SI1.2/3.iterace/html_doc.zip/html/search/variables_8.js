var searchData=
[
  ['installed_5fapps',['INSTALLED_APPS',['../namespaceapp_1_1app_1_1settings.html#a24571ea54b864ef40da4c957ca1cb54e',1,'app::app::settings']]]
];
