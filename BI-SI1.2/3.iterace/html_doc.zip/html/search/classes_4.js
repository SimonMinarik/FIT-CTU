var searchData=
[
  ['handlerfactory',['HandlerFactory',['../classapp_1_1corona_1_1business__layer_1_1handlers_1_1interfaces_1_1handler__factory_1_1_handler_factory.html',1,'app::corona::business_layer::handlers::interfaces::handler_factory']]],
  ['hygienicstation',['HygienicStation',['../classapp_1_1corona_1_1models_1_1_hygienic_station.html',1,'app::corona::models']]]
];
