var searchData=
[
  ['_5f_5fstr_5f_5f',['__str__',['../classapp_1_1corona_1_1models_1_1_patient.html#a23e8041ce1015febe4fdace3225714f9',1,'app.corona.models.Patient.__str__()'],['../classapp_1_1corona_1_1models_1_1_hygienic_station.html#a23e8041ce1015febe4fdace3225714f9',1,'app.corona.models.HygienicStation.__str__()'],['../classapp_1_1corona_1_1models_1_1_covid_test.html#a23e8041ce1015febe4fdace3225714f9',1,'app.corona.models.CovidTest.__str__()'],['../classapp_1_1corona_1_1models_1_1_covid_pass.html#a23e8041ce1015febe4fdace3225714f9',1,'app.corona.models.CovidPass.__str__()']]]
];
