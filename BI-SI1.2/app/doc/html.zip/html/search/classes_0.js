var searchData=
[
  ['administrative',['Administrative',['../classapp_1_1corona_1_1models_1_1_administrative.html',1,'app::corona::models']]]
];
