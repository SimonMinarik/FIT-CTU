var searchData=
[
  ['settings_2epy',['settings.py',['../settings_8py.html',1,'']]]
];
