var searchData=
[
  ['closehour',['closehour',['../classapp_1_1corona_1_1models_1_1_hygienic_station.html#a847e58e3753a6c5e1e567d7941ad53de',1,'app::corona::models::HygienicStation']]],
  ['covidpass',['covidpass',['../classapp_1_1corona_1_1models_1_1_reservation.html#a4303c2803c1b1e13bfb2ac0ff7a5f2c9',1,'app::corona::models::Reservation']]],
  ['covidtest',['covidtest',['../classapp_1_1corona_1_1forms_1_1_patient_register_form.html#ab1643ffbb6bfc242cfd787d1d44e8b0b',1,'app.corona.forms.PatientRegisterForm.covidtest()'],['../classapp_1_1corona_1_1models_1_1_covid_pass.html#ab1643ffbb6bfc242cfd787d1d44e8b0b',1,'app.corona.models.CovidPass.covidtest()']]],
  ['createdate',['createdate',['../classapp_1_1corona_1_1models_1_1_reservation.html#a671bf3321db15f3e737d1b9eb1f5fe6f',1,'app::corona::models::Reservation']]]
];
