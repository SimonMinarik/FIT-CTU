var searchData=
[
  ['waitdays',['waitdays',['../classapp_1_1corona_1_1models_1_1_covid_test.html#aa474793a4887d02b756ed74b6666d92e',1,'app::corona::models::CovidTest']]],
  ['wsgi_2epy',['wsgi.py',['../wsgi_8py.html',1,'']]],
  ['wsgi_5fapplication',['WSGI_APPLICATION',['../namespaceapp_1_1app_1_1settings.html#a9c343ae6b8eb80ef2de562528f3f00b9',1,'app::app::settings']]]
];
