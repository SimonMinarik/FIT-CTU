var searchData=
[
  ['registerpatientview',['RegisterPatientView',['../classapp_1_1corona_1_1presentation__layer_1_1views_1_1register__patient__view_1_1_register_patient_view.html',1,'app::corona::presentation_layer::views::register_patient_view']]],
  ['reservation',['Reservation',['../classapp_1_1corona_1_1models_1_1_reservation.html',1,'app::corona::models']]],
  ['reservationdataaccess',['ReservationDataAccess',['../classapp_1_1corona_1_1data__layer_1_1reservation__data__access_1_1_reservation_data_access.html',1,'app::corona::data_layer::reservation_data_access']]],
  ['reservationdataaccessinterface',['ReservationDataAccessInterface',['../classapp_1_1corona_1_1data__layer_1_1interfaces_1_1reservation__data__access__interface_1_1_reservation_data_access_interface.html',1,'app::corona::data_layer::interfaces::reservation_data_access_interface']]],
  ['reservationform',['ReservationForm',['../classapp_1_1corona_1_1forms_1_1_reservation_form.html',1,'app::corona::forms']]],
  ['reservationhandler',['ReservationHandler',['../classapp_1_1corona_1_1business__layer_1_1handlers_1_1reservation__handler_1_1_reservation_handler.html',1,'app::corona::business_layer::handlers::reservation_handler']]],
  ['reservationhandlerinterface',['ReservationHandlerInterface',['../classapp_1_1corona_1_1business__layer_1_1handlers_1_1interfaces_1_1reservation__handler__interfaedbb78edb575312e4f2e4ab7761d7a33.html',1,'app::corona::business_layer::handlers::interfaces::reservation_handler_interface']]],
  ['reservationview',['ReservationView',['../classapp_1_1corona_1_1presentation__layer_1_1views_1_1reservation__view_1_1_reservation_view.html',1,'app::corona::presentation_layer::views::reservation_view']]]
];
