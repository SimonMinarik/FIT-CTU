var searchData=
[
  ['email',['email',['../classapp_1_1corona_1_1forms_1_1_patient_register_form.html#acba0eb96d8dc53394f4bc448317402ed',1,'app.corona.forms.PatientRegisterForm.email()'],['../classapp_1_1corona_1_1models_1_1_patient.html#acba0eb96d8dc53394f4bc448317402ed',1,'app.corona.models.Patient.email()']]]
];
