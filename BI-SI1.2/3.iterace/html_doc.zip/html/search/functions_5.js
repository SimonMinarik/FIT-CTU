var searchData=
[
  ['main',['main',['../namespaceapp_1_1manage.html#a4f9a0a9111f0da3af151a6c0b4b8a5ca',1,'app::manage']]]
];
