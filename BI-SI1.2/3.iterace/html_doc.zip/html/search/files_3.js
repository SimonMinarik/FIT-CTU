var searchData=
[
  ['data_5faccess_5ffactory_2epy',['data_access_factory.py',['../data__access__factory_8py.html',1,'']]],
  ['doctor_5flogin_2epy',['doctor_login.py',['../doctor__login_8py.html',1,'']]],
  ['doctor_5fregister_5fpatient_5fview_2epy',['doctor_register_patient_view.py',['../doctor__register__patient__view_8py.html',1,'']]],
  ['doctor_5fview_2epy',['doctor_view.py',['../doctor__view_8py.html',1,'']]]
];
