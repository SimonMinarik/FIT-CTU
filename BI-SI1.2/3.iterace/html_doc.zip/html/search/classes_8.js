var searchData=
[
  ['quarantine',['Quarantine',['../classapp_1_1corona_1_1models_1_1_quarantine.html',1,'app::corona::models']]]
];
