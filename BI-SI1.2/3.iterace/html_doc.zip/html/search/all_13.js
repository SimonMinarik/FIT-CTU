var searchData=
[
  ['urlpatterns',['urlpatterns',['../namespaceapp_1_1app_1_1urls.html#a885d935e702b2639d5893d720e71fde8',1,'app::app::urls']]],
  ['urls_2epy',['urls.py',['../urls_8py.html',1,'']]],
  ['use_5fi18n',['USE_I18N',['../namespaceapp_1_1app_1_1settings.html#aa385f7186a262f3a197d89b86cd5b44f',1,'app::app::settings']]],
  ['use_5fl10n',['USE_L10N',['../namespaceapp_1_1app_1_1settings.html#a2578e043379f868f8693d8299d915972',1,'app::app::settings']]],
  ['use_5ftz',['USE_TZ',['../namespaceapp_1_1app_1_1settings.html#a1ad6572b69b47cfda1778bf6e9cb6343',1,'app::app::settings']]],
  ['user',['user',['../classapp_1_1corona_1_1models_1_1_patient.html#a5cc32e366c87c4cb49e4309b75f57d64',1,'app.corona.models.Patient.user()'],['../classapp_1_1corona_1_1models_1_1_administrative.html#a5cc32e366c87c4cb49e4309b75f57d64',1,'app.corona.models.Administrative.user()'],['../classapp_1_1corona_1_1models_1_1_doctor.html#a5cc32e366c87c4cb49e4309b75f57d64',1,'app.corona.models.Doctor.user()']]],
  ['user_5fdata_5faccess_2epy',['user_data_access.py',['../user__data__access_8py.html',1,'']]],
  ['user_5fdata_5faccess_5finterface_2epy',['user_data_access_interface.py',['../user__data__access__interface_8py.html',1,'']]],
  ['user_5fhandler_2epy',['user_handler.py',['../user__handler_8py.html',1,'']]],
  ['user_5fhandler_5finterface_2epy',['user_handler_interface.py',['../user__handler__interface_8py.html',1,'']]],
  ['userdataaccess',['UserDataAccess',['../classapp_1_1corona_1_1data__layer_1_1user__data__access_1_1_user_data_access.html',1,'app::corona::data_layer::user_data_access']]],
  ['userdataaccessinterface',['UserDataAccessInterface',['../classapp_1_1corona_1_1data__layer_1_1interfaces_1_1user__data__access__interface_1_1_user_data_access_interface.html',1,'app::corona::data_layer::interfaces::user_data_access_interface']]],
  ['userhandler',['UserHandler',['../classapp_1_1corona_1_1business__layer_1_1handlers_1_1user__handler_1_1_user_handler.html',1,'app::corona::business_layer::handlers::user_handler']]],
  ['userhandlerinterface',['UserHandlerInterface',['../classapp_1_1corona_1_1business__layer_1_1handlers_1_1interfaces_1_1user__handler__interface_1_1_user_handler_interface.html',1,'app::corona::business_layer::handlers::interfaces::user_handler_interface']]],
  ['username',['username',['../classapp_1_1corona_1_1forms_1_1_login_form.html#a0adcbe0e0e6f64a29b1d205ede9632c1',1,'app.corona.forms.LoginForm.username()'],['../classapp_1_1corona_1_1forms_1_1_patient_register_form.html#a0adcbe0e0e6f64a29b1d205ede9632c1',1,'app.corona.forms.PatientRegisterForm.username()']]]
];
